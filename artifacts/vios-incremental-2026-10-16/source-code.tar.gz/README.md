# VIOS / Agon Light 2

VIOS is an Agon-first, malleable Forth operating-system foundation. It runs on the physical Agon Light 2 with native 24-bit cells, eZ80 assembly direct/token engines and a standard-C semantic reference. The default is **DIRECT**. The compiler emits both native representations and retains definition source for inspection and live development.

The resident system integrates the full VDP, concurrent framed USB control, native SD/FAT32, replaceable Forth service bindings, transactional source modules and A/B source startup. The [physical-board acceptance](docs/bring-up/vios-resident-accepted-run3.json) passed 137 checkpoints, including real module save/reload and v1 → v2 → v1 startup. [Recovery acceptance](docs/bring-up/vios-resident-recovery-run1.json) passed pending-input, infinite graphics-loop and automatic watchdog-reset cases. The [resident runbook](docs/bring-up/vios-resident-system.md) records limits and recovery details.

The native engine measurements show direct threading taking **11–14% less time than token threading** across five measured workloads. The incremental workbench CPU image is 105,232 bytes, with 254,031 bytes of BSS and a separate 4 KiB stack. The dictionary capacity is 512 configurable entries. See the [workbench/VM measurements](docs/benchmarks/workbench-2026-10-16.md) and [incremental composition measurements](docs/benchmarks/incremental-2026-10-16.md). These measurements describe this implementation and these workloads.

Build with the provisioned AgonDev and PlatformIO toolchains:

```sh
make vios-resident test verify-forth-engine
~/.platformio/penv/bin/pio run -d firmware/esp32-vios -e esp32-vios
```

For the installed resident firmware, start one persistent host harness:

```sh
.venv/bin/python tools/vios_harness.py --backend resident --tcp 127.0.0.1:8765
```

Call its `connect` tool to attach without uploading an image. For MCP stdio, omit `--tcp`; the [harness runbook](docs/bring-up/vios-harness.md) includes client configuration for 48 tools, including 19 workbench tools. MCP/JSON/TCP run on the host, and a compact binary protocol runs over USB serial. The CH340 does not provide a native USB network interface.

A human CLI attaches to the existing TCP harness:

```sh
.venv/bin/python tools/vios_cli.py
```

Forth lines, inspection, explicit KEY input and recovery are available headlessly. `:recover` intentionally discards unsaved RAM state and restarts the resident supervisor. One process owns the serial port; do not start another harness while one is running. See [CLI usage](docs/bring-up/vios-cli.md).

ESP32 app0 embeds the CPU RAM image and verifies it through ZDI at startup. Original eZ80 flash remains untouched. The ESP32 bootloader/partition table/app1 were preserved, and the original firmware backups remain available. The [resident runbook](docs/bring-up/vios-resident-system.md) includes the application-only restore command. The earlier temporary RAM bridge is retained as `--backend ram`; its [historical runbook](docs/bring-up/vios-harness-ram-profile.md) and [wiring prerequisites](docs/bring-up/ram-console.md) remain separate.

The [hybrid text workbench](docs/bring-up/vios-workbench.md) provides a browser, exact-source editor and live inspector in mode 1 (80×60 cells). The CLI supports `:wb open`, `:wb view` and `:wb close`; keyboard and LLM tools share the same guarded operations. Retained panes, indexed source lines and sparse character/style runs replace the full-frame rebuild on ordinary updates. A 60-byte dirty-row index keeps the measured 32-byte edit render near 4.2 ms. Composition and transmission are measured separately. The plain CLI and independent supervisor recovery remain available.

- [Resident system and limits](docs/bring-up/vios-resident-system.md)
- [Text workbench runbook](docs/bring-up/vios-workbench.md)
- [Rendering benchmarks and limits](docs/benchmarks/workbench-2026-10-16.md)
- [Incremental composition benchmarks](docs/benchmarks/incremental-2026-10-16.md)
- [Resident implementation/evidence ledger](docs/bring-up/vios-resident-progress.md)
- [Original Forth milestone](docs/bring-up/vios-forth.md)
- [Hardware reference](docs/research/hardware.md)
- [Original eZ80 backup metadata](backups/ez80/original-2026-10-16.json)

This workspace is not currently a Git repository. Archived references retain their notices and licenses. ESP32 ZDI protocol code derives from the MIT-licensed Agon recovery project; see `tools/esp32-ram/NOTICE.txt`. Vendored VDP and vdp-gl retain their own licenses and pinned source identities.
