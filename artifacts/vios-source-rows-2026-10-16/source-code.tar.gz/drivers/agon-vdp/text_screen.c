#include "vios/text_screen.h"
#include "platform/vdp.h"
#define CELL_COUNT (VIOS_TEXT_COLUMNS*VIOS_TEXT_ROWS)
/* Exactly 19,200 bytes: no heap, per-cell flags, or third screen copy. */
static struct vios_text_cell desired[CELL_COUNT],painted[CELL_COUNT];
static unsigned paint_cursor,dirty_cells;
static unsigned char dirty_rows[VIOS_TEXT_ROWS];
static struct vios_text_stats stats;
static uint32_t generation;
uint32_t vios_text_generation(void) {return generation;}
static int dirty(unsigned index) {
 return desired[index].ch!=painted[index].ch||desired[index].attr!=painted[index].attr;
}
void vios_text_stats_reset(void) {stats.cells=stats.spans=stats.batches=stats.bytes=0;}
void vios_text_begin_frame(void) {
 ++generation;
 dirty_cells=0;unsigned index=0;
 for(unsigned row=0;row<VIOS_TEXT_ROWS;++row){
  dirty_rows[row]=0;
  for(unsigned col=0;col<VIOS_TEXT_COLUMNS;++col,++index){
   desired[index].ch=' ';desired[index].attr=3;
   if(index<CELL_COUNT-1&&(painted[index].ch!=' '||painted[index].attr!=3)){++dirty_cells;++dirty_rows[row];}
  }
 }
}
void vios_text_reset(void) {
 ++generation;
 for(unsigned i=0;i<CELL_COUNT;++i){desired[i].ch=painted[i].ch=' ';desired[i].attr=painted[i].attr=3;}
 for(unsigned row=0;row<VIOS_TEXT_ROWS;++row)dirty_rows[row]=0;
 paint_cursor=dirty_cells=0;vios_text_stats_reset();
}
void vios_text_clear(unsigned x,unsigned y,unsigned width,unsigned height) {
 if(x>=VIOS_TEXT_COLUMNS||y>=VIOS_TEXT_ROWS)return;
 if(width>VIOS_TEXT_COLUMNS-x)width=VIOS_TEXT_COLUMNS-x;
 if(height>VIOS_TEXT_ROWS-y)height=VIOS_TEXT_ROWS-y;
 for(unsigned row=y;row<y+height;++row){
  unsigned index=row*VIOS_TEXT_COLUMNS+x,end=index+width;
  if(end==CELL_COUNT)--end;
  for(;index<end;++index){
   if(dirty(index)){--dirty_cells;--dirty_rows[row];}
   desired[index].ch=' ';desired[index].attr=3;
   if(dirty(index)){++dirty_cells;++dirty_rows[row];}
  }
 }
}
void vios_text_put(unsigned x,unsigned y,const char *text,size_t length,unsigned fg,unsigned bg) {
 if(x>=VIOS_TEXT_COLUMNS||y>=VIOS_TEXT_ROWS||!text)return;
 unsigned available=VIOS_TEXT_COLUMNS-x;
 if(length>available)length=available;
 unsigned index=y*VIOS_TEXT_COLUMNS+x;
 unsigned char attr=(unsigned char)((fg&15)|((bg&15)<<4));
 for(size_t n=0;n<length;++n,++index) {
  /* Printing the bottom-right cell would scroll the entire VDP viewport. */
  if(index==CELL_COUNT-1)break;
  unsigned char ch=(unsigned char)text[n];
  if(dirty(index)){--dirty_cells;--dirty_rows[y];}
  desired[index].ch=ch>=32&&ch<=126?ch:'?';desired[index].attr=attr;
  if(dirty(index)){++dirty_cells;++dirty_rows[y];}
 }
}
int vios_text_cell(unsigned x,unsigned y,struct vios_text_cell *out) {
 if(x>=VIOS_TEXT_COLUMNS||y>=VIOS_TEXT_ROWS||!out)return 0;
 *out=desired[y*VIOS_TEXT_COLUMNS+x];return 1;
}
int vios_text_pending(void) {return dirty_cells!=0;}
static unsigned scan_row(unsigned index,unsigned end) {
 const struct vios_text_cell *want=desired+index,*seen=painted+index;
 while(index<end){
  if(want->ch!=seen->ch||want->attr!=seen->attr)return index;
  ++index;++want;++seen;
 }
 return CELL_COUNT;
}
/* Keep row lookup out of the eZ80 batch writer: inlining combines their
 * register pressure and makes even clean-row skips spill many stack locals. */
#if defined(__GNUC__)
__attribute__((noinline))
#endif
static unsigned find_dirty(unsigned start) {
 unsigned row=start/VIOS_TEXT_COLUMNS,row_end=(row+1)*VIOS_TEXT_COLUMNS;
 if(row_end==CELL_COUNT)--row_end;
 if(dirty_rows[row]){unsigned index=scan_row(start,row_end);if(index!=CELL_COUNT)return index;}
 const unsigned char *first=dirty_rows+row,*next=first;
 /* Skip clean rows using only their byte counters. Revisit the first row
  * after wrapping to catch changed cells before the persistent cursor. */
 do{
  if(++next==dirty_rows+VIOS_TEXT_ROWS)next=dirty_rows;
  if(*next){
   unsigned row_start=(unsigned)(next-dirty_rows)*VIOS_TEXT_COLUMNS;
   row_end=row_start+VIOS_TEXT_COLUMNS;if(row_end==CELL_COUNT)--row_end;
   return scan_row(row_start,row_end);
  }
 }while(next!=first);
 return CELL_COUNT;
}
unsigned vios_text_render(unsigned budget) {
 unsigned char bytes[VIOS_TEXT_BATCH_BYTES];unsigned used=0;
 if(budget>sizeof bytes)budget=sizeof bytes;
 while(dirty_cells&&budget-used>=8) {
  unsigned index=find_dirty(paint_cursor);if(index==CELL_COUNT)break;
  unsigned row=index/VIOS_TEXT_COLUMNS,row_end=(row+1)*VIOS_TEXT_COLUMNS;
  if(row_end==CELL_COUNT)--row_end;
  unsigned char attr=desired[index].attr;
  bytes[used++]=17;bytes[used++]=attr&15;
  bytes[used++]=17;bytes[used++]=(unsigned char)(128|(attr>>4));
  bytes[used++]=31;bytes[used++]=(unsigned char)(index%VIOS_TEXT_COLUMNS);
  bytes[used++]=(unsigned char)(index/VIOS_TEXT_COLUMNS);++stats.spans;
  do {
   bytes[used++]=desired[index].ch;painted[index]=desired[index];--dirty_cells;--dirty_rows[row];++stats.cells;++index;
  }while(used<budget&&index<row_end&&dirty(index)&&desired[index].attr==attr);
  paint_cursor=index==CELL_COUNT-1?0:index;
 }
 if(used){platform_vdp_send(bytes,used);++stats.batches;stats.bytes+=used;}
 return used;
}
void vios_text_stats(struct vios_text_stats *out) {if(out)*out=stats;}
