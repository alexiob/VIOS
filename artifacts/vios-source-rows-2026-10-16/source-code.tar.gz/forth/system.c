/* VIOS resident dual-emitting compiler. CPU execution stays behind vm.h. */
#include "forth/system.h"
#include "forth/inspect.h"
#include "forth/modules.h"
#include "platform/console.h"
#include "platform/system.h"
#include "vios/config.h"
#define WORDS_MAX VIOS_FORTH_WORDS_MAX
#define NAME_MAX 31
#define TOKEN_BYTES 16384
#define DIRECT_BYTES 32768
#define DATA_BYTES 8192
#define SOURCE_BYTES 8192
#define CONTROL_MAX 64
#define HASH_BUCKETS VIOS_FORTH_HASH_BUCKETS

enum { WK_PRIMITIVE,WK_COLON,WK_CONSTANT,WK_VARIABLE,WK_DEFER,WK_NATIVE };
enum { CS_IF,CS_ELSE,CS_BEGIN,CS_WHILE,CS_DO };
struct word {
 char name[NAME_MAX+1]; fcell token,direct,aux;
 unsigned short link,source,length,token_length,direct_length,origin; unsigned char kind,opcode;
};
struct control { unsigned char kind; size_t token,direct; };
static struct word words[WORDS_MAX];
static unsigned short buckets[HASH_BUCKETS];
static unsigned char token_code[TOKEN_BYTES],direct_code[DIRECT_BYTES],data_space[DATA_BYTES];
static char source_space[SOURCE_BYTES];
static struct control controls[CONTROL_MAX];
static size_t token_used,direct_used,data_used,source_used,control_used;
static size_t mark_token,mark_direct,mark_data,mark_source;
static unsigned count;
static int current;
static enum forth_engine selected;
static fcell base_address;
static char error_text[96];
static unsigned char transport_crc;
static const char *vm_message(void);
#define NATIVES_MAX 32
static struct {int (*callback)(void);unsigned flags;} natives[NATIVES_MAX];
static unsigned native_count,origin_id;
static int (*outer_hook)(const char *,const char **);
static void (*idle_hook)(int);
static int transaction_active,have_activation;
static fcell transaction_budget;
static uint32_t catalog_revision;
static int observer_active;
static fcell observer_budget;
/* The observer saves application values, not the 8 KiB transaction arena. */
static struct {
 fcell stack[FVM_DS],depth,ip,error,budget,ds_peak,rs_peak,base;
 enum forth_engine engine;
 char error_text[96];
} observer_before;
static void catalog_changed(void) {if(!++catalog_revision)++catalog_revision;}
struct checkpoint {
 size_t token,direct,data,source;unsigned count;
 unsigned short buckets[HASH_BUCKETS];
 unsigned char data_bytes[DATA_BYTES];
 fcell stack[FVM_DS],depth,ip,error,budget,ds_peak,rs_peak,base;
 enum forth_engine engine;
};
static struct checkpoint transaction_before,activation_before;
static unsigned char test_data[DATA_BYTES];
static size_t activation_token,activation_direct,activation_data,activation_source;
static unsigned activation_count;
static unsigned transaction_words;
static size_t transaction_token,transaction_direct,transaction_data;

static size_t length(const char *s) { size_t n=0;while(s[n])++n;return n; }
static int equal(const char *a,const char *b) { while(*a&&*a==*b){++a;++b;}return *a==*b; }
static char upper(char c) {return c>='a'&&c<='z'?(char)(c-'a'+'A'):c;}
static void copy(char *d,const char *s) {while((*d++=*s++)) {}}
static void print(const char *s) {while(*s)platform_console_putc((unsigned char)*s++);}
static void unsigned_number(fcell n) {
 char buf[24];unsigned i=0;fcell radix=fvm_read_cell(base_address);
 if(radix<2||radix>36)radix=10;
 do {unsigned d=(unsigned)(n%radix);buf[i++]=(char)(d<10?'0'+d:'A'+d-10);n/=radix;}while(n);
 while(i)platform_console_putc((unsigned char)buf[--i]);
}
static void number(fcell n) {
 if(n&0x800000UL) {platform_console_putc('-');n=((~n)+1)&FVM_MASK;}
 unsigned_number(n);platform_console_putc(' ');
}
static void decimal_number(fcell n) {
 char b[16];unsigned i=0;do {b[i++]=(char)('0'+n%10);n/=10;}while(n);
 while(i)platform_console_putc((unsigned char)b[--i]);
}
static void rollback(void) {
 if(current>=0) {token_used=mark_token;direct_used=mark_direct;data_used=mark_data;source_used=mark_source;}
 current=-1;control_used=0;
}
static int fail(const char *s) {
 copy(error_text,s);rollback();fvm_depth=fvm_rdepth=fvm_ldepth=0;return 0;
}
int forth_error(const char *s){return fail(s?s:"native service failed");}
int forth_transaction_error(const char *s){copy(error_text,s);return 0;}
int forth_transaction_active(void){return transaction_active;}
static int unknown(const char *name) {
 char s[96];copy(s,"unknown word: ");copy(s+14,name);return fail(s);
}
static unsigned hash(const char *name) {
 unsigned h=0;while(*name)h=(h*33u+(unsigned char)*name++)&(HASH_BUCKETS-1);return h;
}
static int find(const char *name) {
 unsigned n=buckets[hash(name)];while(n) {if(equal(words[n-1].name,name))return (int)n-1;n=words[n-1].link;}return -1;
}
static fcell address(const unsigned char *p) {return fvm_address(p);}
static void put_cell(unsigned char *p,fcell n) {p[0]=(unsigned char)n;p[1]=(unsigned char)(n>>8);p[2]=(unsigned char)(n>>16);}
static fcell primitive(unsigned op) {
#ifdef __ez80__
 return fvm_direct_primitives[op];
#else
 return (fcell)(0xf00000UL+op*4u);
#endif
}
static fcell docol_address(void) {
#ifdef __ez80__
 return (fcell)(uintptr_t)&fvm_docol;
#else
 return 0xf10000UL;
#endif
}
static int room(size_t t,size_t d) {
 if(t>TOKEN_BYTES-token_used||d>DIRECT_BYTES-direct_used)return fail("code dictionary full");return 1;
}
static int op(unsigned n) {
 if(!room(1,3))return 0;
 token_code[token_used++]=(unsigned char)n;put_cell(direct_code+direct_used,primitive(n));direct_used+=3;return 1;
}
static int operand(fcell t,fcell d) {
 if(!room(3,3))return 0;
 put_cell(token_code+token_used,t);token_used+=3;put_cell(direct_code+direct_used,d);direct_used+=3;return 1;
}
static int literal(fcell n) {return op(F_LIT)&&operand(n,n);}
static int begin_word(const char *name,unsigned kind) {
 if(current>=0)return fail("nested definition");
 if(count==WORDS_MAX)return fail("dictionary full");
 if(!*name||length(name)>NAME_MAX)return fail("invalid name");
 mark_token=token_used;mark_direct=direct_used;mark_data=data_used;mark_source=source_used;
 current=(int)count;words[count].kind=(unsigned char)kind;copy(words[count].name,name);
 words[count].origin=(unsigned short)origin_id;
 words[count].aux=0;words[count].source=(unsigned short)source_used;words[count].length=0;
 words[count].token=address(token_code+token_used);words[count].direct=address(direct_code+direct_used);
 if(!room(0,4))return 0;
 direct_code[direct_used++]=0xcd;put_cell(direct_code+direct_used,docol_address());direct_used+=3;return 1;
}
static int source_add(const char *s) {
 size_t n=length(s);
 if(n+1>SOURCE_BYTES-source_used)return fail("source dictionary full");
 while(*s)source_space[source_used++]=*s++;
 source_space[source_used++]=' ';return 1;
}
static int string_literal(const char **input) {
 const char *p=*input;if(*p==' '||*p=='\t')++p;
 const char *start=p;while(*p&&*p!='"'&&*p!='\r'&&*p!='\n')++p;
 if(*p!='"')return fail("unterminated string");
 size_t n=(size_t)(p-start);
 if(n+1>DATA_BYTES-data_used)return fail("data space full");
 if(current<0&&fvm_depth>FVM_DS-2)return fail("data stack overflow");
 if(current>=0) {
  if(n+2>SOURCE_BYTES-source_used)return fail("source dictionary full");
  for(size_t i=0;i<n;++i)source_space[source_used++]=start[i];
  source_space[source_used++]='"';source_space[source_used++]=' ';
 }
 fcell a=address(data_space+data_used);data_used+=n+1;
 for(size_t i=0;i<n;++i)fvm_write8(a+(fcell)i,(unsigned char)start[i]);
 fvm_write8(a+(fcell)n,0);*input=p+1;
 if(fvm_error)return fail(vm_message());
 return current>=0?(literal(a)&&literal((fcell)n)):(fvm_push(a)&&fvm_push((fcell)n));
}
static int publish(void) {
 unsigned h=hash(words[count].name);
 words[count].link=buckets[h];words[count].length=(unsigned short)(source_used-words[count].source);
 words[count].token_length=(unsigned short)(token_used-mark_token);
 words[count].direct_length=(unsigned short)(direct_used-mark_direct);
 buckets[h]=(unsigned short)(count+1);++count;current=-1;
 if(!transaction_active)catalog_changed();return 1;
}
static int compile_word(int n) {
 struct word *w=&words[n];
 if(w->kind==WK_PRIMITIVE)return op(w->opcode);
 if(w->kind==WK_CONSTANT||w->kind==WK_VARIABLE)return literal(w->aux);
 if(!room(4,3))return 0;
 token_code[token_used++]=F_CALL;put_cell(token_code+token_used,w->token);token_used+=3;
 put_cell(direct_code+direct_used,w->direct);direct_used+=3;return 1;
}
static const char *vm_message(void) {
 static const char *const messages[]={"ok","data stack underflow","data stack overflow","return stack underflow","return stack overflow","loop stack underflow","loop stack overflow","invalid memory","invalid opcode","execution budget exhausted","arithmetic error"};
 return fvm_error<sizeof(messages)/sizeof(messages[0])?messages[fvm_error]:"VM error";
}
static int call_xt(fcell xt) {
 if(!xt||xt>count)return fail("invalid execution token");
 if(fvm_rdepth==FVM_RS)return fail("return stack overflow");
 fvm_rs[fvm_rdepth++]=fvm_ip;
 if(fvm_rdepth>fvm_rs_peak)fvm_rs_peak=fvm_rdepth;
 fvm_ip=selected==FORTH_DIRECT?words[xt-1].direct+4:words[xt-1].token;
 return 1;
}
static int execute_index(unsigned n) {
 fvm_error=0;fvm_rdepth=fvm_ldepth=0;
 fvm_budget=observer_active?observer_budget:transaction_active?transaction_budget:1000000UL;
 fvm_ip=selected==FORTH_DIRECT?words[n].direct+4:words[n].token;
 for(;;) {
  unsigned char result;
#ifdef __ez80__
  if(selected==FORTH_DIRECT)result=fvm_direct_run();
  else if(selected==FORTH_TOKEN)result=fvm_token_run();
  else result=fvm_reference_run();
#else
  result=fvm_reference_run();
#endif
  if(transaction_active)transaction_budget=fvm_budget;
  if(observer_active)observer_budget=fvm_budget;
  if(fvm_error)return fail(vm_message());
  if(!result)return 1;
  unsigned code=result-0x80u;
  if(observer_active&&code==F_KEY)return fail("KEY disabled during observer");
  if(transaction_active&&(code==F_EMIT||code==F_DOT||code==F_CR||code==F_KEY))return fail("I/O disabled during module transaction");
  if(code==F_EMIT) {fcell c=fvm_pop();if(!fvm_error)platform_console_putc((unsigned char)c);}
  else if(code==F_DOT) {fcell nvalue=fvm_pop();if(!fvm_error)number(nvalue);}
  else if(code==F_CR)print("\r\n");
  else if(code==F_KEY) {int c;do {c=platform_console_getc();}while(c<0);fvm_push((fcell)c);}
  else if(code==F_EXECUTE||code==F_DEFER) {fcell xt=fvm_pop();if(!fvm_error&&!call_xt(xt))return 0;}
  else if(code==F_NATIVE) {
   fcell id=fvm_pop();if(fvm_error)return fail(vm_message());
   if(id>=native_count)return fail("invalid native service");
   if(transaction_active&&!(natives[id].flags&FORTH_NATIVE_PURE))return fail("native I/O disabled during module transaction");
   if(!natives[id].callback())return error_text[0]?0:fail("native service failed");
  }
  else if(!fvm_complex(code))return fail(vm_message());
  if(fvm_error)return fail(vm_message());
 }
}
int forth_execute(const char *name) {
 if(!name||length(name)>NAME_MAX)return fail("invalid word name");
 fcell xt=forth_find_xt(name);return xt?execute_index((unsigned)(xt-1)):unknown(name);
}
fcell forth_find_xt(const char *name) {
 char key[NAME_MAX+1];unsigned i=0;
 if(!name)return 0;
 while(name[i]){if(i==NAME_MAX)return 0;key[i]=upper(name[i]);++i;}key[i]=0;
 int n=find(key);return n<0?0:(fcell)(n+1);
}
const char *forth_xt_name(fcell xt){return xt&&xt<=count?words[xt-1].name:NULL;}
int forth_register_command(int (*hook)(const char *,const char **)) {
 if(transaction_active)return fail("command registration during module transaction");
 outer_hook=hook;return 1;
}
void forth_register_idle(void (*hook)(int)) {idle_hook=hook;}
int forth_register_native(const char *name,int (*callback)(void),unsigned flags) {
 char key[NAME_MAX+1];unsigned i=0;
 if(transaction_active)return fail("native registration during module transaction");
 if(!name||!callback||native_count==NATIVES_MAX)return fail("native registry full or invalid");
 while(name[i]){if(i==NAME_MAX)return fail("invalid name");key[i]=upper(name[i]);++i;}key[i]=0;
 if(!begin_word(key,WK_NATIVE))return 0;
 words[count].aux=native_count;
 if(!op(F_NATIVE)||!operand(native_count,native_count)||!op(F_EXIT))return 0;
 natives[native_count].callback=callback;natives[native_count++].flags=flags;
 return publish();
}
static int next_token(const char **p,char *buf) {
 for(;;) {
  while(**p&&(**p==' '||**p=='\t'||**p=='\r'||**p=='\n'))++*p;
  if(**p=='\\') {while(**p&&**p!='\n')++*p;continue;}
  if(**p=='(') {while(**p&&**p!=')')++*p;if(**p)++*p;continue;}break;
 }
 if(!**p)return 0;
 unsigned n=0;while(**p&&**p!=' '&&**p!='\t'&&**p!='\r'&&**p!='\n') {
  if(n==NAME_MAX){fail("token too long");return -1;}
  buf[n++]=upper(*(*p)++);
 }
 buf[n]=0;return 1;
}
static int need_token(const char **p,char *buf) {return next_token(p,buf)>0?1:fail("missing name");}
static int parse_number(const char *s,fcell *value) {
 int negative=0;fcell n=0,radix=fvm_read_cell(base_address);
 if(*s=='-'||*s=='+'){negative=*s=='-';++s;}
 if(*s=='$'){radix=16;++s;}else if(*s=='%'){radix=2;++s;}
 if(!*s||radix<2||radix>36)return 0;
 while(*s) {
  unsigned d=*s>='0'&&*s<='9'?(unsigned)(*s-'0'):*s>='A'&&*s<='Z'?(unsigned)(*s-'A'+10):99u;
  if(d>=radix)return 0;
  if(n>(FVM_MASK-d)/radix)return -1;
  n=n*radix+d;++s;
 }
 *value=negative?((~n)+1)&FVM_MASK:n;return 1;
}
static int control_push(unsigned kind,size_t t,size_t d) {
 if(control_used==CONTROL_MAX)return fail("compiler control stack full");
 controls[control_used].kind=(unsigned char)kind;controls[control_used].token=t;controls[control_used++].direct=d;return 1;
}
static void patch(struct control c) {
 put_cell(token_code+c.token,address(token_code+token_used));
 put_cell(direct_code+c.direct,address(direct_code+direct_used));
}
static int control_word(const char *s) {
 struct control c;
 if(current<0)return fail("compile-only word");
 if(equal(s,"IF")||equal(s,"WHILE")) {
  if(equal(s,"WHILE")&&(!control_used||controls[control_used-1].kind!=CS_BEGIN))return fail("WHILE needs BEGIN");
  if(!op(F_ZBRANCH))return 0;
  if(!control_push(equal(s,"IF")?CS_IF:CS_WHILE,token_used,direct_used))return 0;
  return operand(0,0);
 }
 if(equal(s,"BEGIN"))return control_push(CS_BEGIN,token_used,direct_used);
 if(equal(s,"DO")){if(!op(F_DO))return 0;return control_push(CS_DO,token_used,direct_used);}
 if(!control_used)return fail("unbalanced control flow");
 c=controls[--control_used];
 if(equal(s,"ELSE")) {
  if(c.kind!=CS_IF)return fail("ELSE needs IF");
  if(!op(F_BRANCH))return 0;
  size_t t=token_used,d=direct_used;if(!operand(0,0))return 0;patch(c);return control_push(CS_ELSE,t,d);
 }
 if(equal(s,"THEN")){if(c.kind!=CS_IF&&c.kind!=CS_ELSE)return fail("THEN needs IF");patch(c);return 1;}
 if(equal(s,"REPEAT")) {
  if(c.kind!=CS_WHILE||!control_used||controls[control_used-1].kind!=CS_BEGIN)return fail("REPEAT needs BEGIN WHILE");
  struct control begin=controls[--control_used];
  if(!op(F_BRANCH)||!operand(address(token_code+begin.token),address(direct_code+begin.direct)))return 0;patch(c);return 1;
 }
 if(equal(s,"LOOP")) {if(c.kind!=CS_DO)return fail("LOOP needs DO");return op(F_LOOP)&&operand(address(token_code+c.token),address(direct_code+c.direct));}
 if(c.kind!=CS_BEGIN)return fail("loop needs BEGIN");
 return op(equal(s,"UNTIL")?F_ZBRANCH:F_BRANCH)&&operand(address(token_code+c.token),address(direct_code+c.direct));
}
static int defining(const char *kind,const char *name) {
 unsigned k=equal(kind,"CONSTANT")?WK_CONSTANT:equal(kind,"DEFER")?WK_DEFER:WK_VARIABLE;
 fcell value=0;
 if(k==WK_CONSTANT){value=fvm_pop();if(fvm_error)return fail(vm_message());}
 if(!begin_word(name,k))return 0;
 if(k==WK_CONSTANT)words[count].aux=value;
 else {
  if(DATA_BYTES-data_used<3)return fail("data space full");
  words[count].aux=address(data_space+data_used);data_used+=3;fvm_write_cell(words[count].aux,0);
 }
 if(k==WK_DEFER) {if(!op(F_DEFER)||!operand(words[count].aux,words[count].aux))return 0;}
 else if(!literal(words[count].aux))return 0;
 if(!op(F_EXIT))return 0;
 return publish();
}
static void show_stack(void) {
 print("<");unsigned_number(fvm_depth);print("> ");
 for(fcell i=0;i<fvm_depth;++i)number(fvm_ds[i]);print("\r\n");
}
static void show_word(int n) {
 if(words[n].length) {
  const char *p=source_space+words[n].source;
  for(unsigned i=0;i<words[n].length;++i)platform_console_putc((unsigned char)p[i]);
 }else {print(words[n].kind==WK_PRIMITIVE?"primitive ":"data word ");print(words[n].name);}
 print("\r\n");
 print("word ");print(words[n].name);print(" xt ");decimal_number((fcell)(n+1));
 print(" kind ");decimal_number(words[n].kind);print(" token ");decimal_number(words[n].token);
 print(" direct ");decimal_number(words[n].direct);print(" token-bytes ");decimal_number(words[n].token_length);
 print(" direct-bytes ");decimal_number(words[n].direct_length);print("\r\n");
 if(words[n].origin) {
  const char *module,*version;uint32_t crc;
  if(forth_module_origin(words[n].origin,&module,&version,&crc)) {
   print("module ");print(module);print(" version ");print(version);print("\r\n");
  }
 }
}
int forth_eval(const char *source) {
 const char *p=source;char s[NAME_MAX+1],name[NAME_MAX+1];int got;
 error_text[0]=0;fvm_error=0;
 while((got=next_token(&p,s))>0) {
  if(transaction_active&&(equal(s,"ABORT")||equal(s,"ENGINE")||equal(s,"BENCH")||equal(s,"SYNC")||equal(s,"WORDS")||equal(s,".S")||equal(s,"SEE")||equal(s,"RESOURCES")))return fail("interactive tool disabled during module transaction");
  if(current<0&&!transaction_active&&outer_hook) {
   int handled=outer_hook(s,&p);if(handled<0)return 0;if(handled)continue;
  }
  /* Harness framing consumes no VM values and never enters a definition. */
  if(equal(s,"SYNC")) {
   if(!need_token(&p,name))return 0;
   print("@");print(name);print("\r\n");continue;
  }
  if(equal(s,"ABORT")){rollback();fvm_reset();return 1;}
  if(equal(s,":")) {
   if(!need_token(&p,name)||!begin_word(name,WK_COLON))return 0;
   if(!source_add(":")||!source_add(name))return 0;continue;
  }
  if(current>=0&&!source_add(s))return 0;
  if(equal(s,"S\"")){if(!string_literal(&p))return 0;continue;}
  if(equal(s,";")) {
   if(current<0)return fail("unexpected semicolon");
   if(control_used)return fail("unbalanced control flow");
   if(!op(F_EXIT)||!publish())return 0;continue;
  }
  if(equal(s,"VARIABLE")||equal(s,"CONSTANT")||equal(s,"DEFER")) {
   if(current>=0)return fail("defining word inside definition");
   if(!need_token(&p,name)||!defining(s,name))return 0;continue;
  }
  if(equal(s,"IF")||equal(s,"ELSE")||equal(s,"THEN")||equal(s,"BEGIN")||equal(s,"UNTIL")||equal(s,"AGAIN")||equal(s,"WHILE")||equal(s,"REPEAT")||equal(s,"DO")||equal(s,"LOOP")) {
   if(!control_word(s))return 0;continue;
  }
  if(equal(s,"RECURSE")) {if(current<0)return fail("RECURSE outside definition");if(!compile_word(current))return 0;continue;}
  if(equal(s,"EXIT")&&current>=0){if(!op(F_EXIT))return 0;continue;}
  if(equal(s,"'")||equal(s,"[']")||equal(s,"IS")) {
   if(!need_token(&p,name))return 0;
   if(current>=0&&!source_add(name))return 0;
   int n=find(name);if(n<0)return unknown(name);
   if(equal(s,"IS")) {
    if(words[n].kind!=WK_DEFER)return fail("IS requires deferred word");
    if(current>=0){if(!literal(words[n].aux)||!op(F_STORE))return 0;}
    else {fcell xt=fvm_pop();if(fvm_error)return fail(vm_message());if(!xt||xt>count)return fail("invalid execution token");fvm_write_cell(words[n].aux,xt);}
   }else {
    if(equal(s,"'")&&current>=0)return fail("use ['] in definitions");
    if(current>=0){if(!literal((fcell)(n+1)))return 0;}else if(!fvm_push((fcell)(n+1)))return fail(vm_message());
   }
   continue;
  }
#ifdef __ez80__
  if(equal(s,"BENCH")) {
   extern void forth_benchmark(void);
   if(current>=0)return fail("interactive tool inside definition");
   forth_benchmark();continue;
  }
#endif
  if(equal(s,"WORDS")||equal(s,".S")||equal(s,"SEE")||equal(s,"RESOURCES")||equal(s,"ENGINE")) {
   if(current>=0)return fail("interactive tool inside definition");
   if(equal(s,"WORDS")){for(unsigned i=0;i<count;++i){print(" ");print(words[i].name);}print(" \r\n");}
   else if(equal(s,".S"))show_stack();
   else if(equal(s,"SEE")){if(!need_token(&p,name))return 0;int n=find(name);if(n<0)return unknown(name);show_word(n);}
   else if(equal(s,"RESOURCES"))forth_report();
   else {
    if(!need_token(&p,name))return 0;
    if(equal(name,"C"))selected=FORTH_REFERENCE;
#ifdef __ez80__
    else if(equal(name,"TOKEN"))selected=FORTH_TOKEN;
    else if(equal(name,"DIRECT"))selected=FORTH_DIRECT;
#endif
    else return fail("engine unavailable");
   }
   continue;
  }
  int n=find(s);
  if(n>=0){if(current>=0){if(!compile_word(n))return 0;}else if(!execute_index((unsigned)n))return 0;continue;}
  fcell value;int numeric=parse_number(s,&value);
  if(numeric<0)return fail("number outside 24-bit range");
  if(!numeric)return unknown(s);
  if(current>=0){if(!literal(value))return 0;}else if(!fvm_push(value))return fail(vm_message());
 }
 return got<0?0:1;
}
void forth_init(void) {
 static const struct {const char *name;unsigned char op;} primitives[]={
 {"DUP",F_DUP},{"DROP",F_DROP},{"SWAP",F_SWAP},{"OVER",F_OVER},{"+",F_ADD},{"-",F_SUB},{"*",F_MUL},{"/",F_DIV},{"MOD",F_MOD},
 {"AND",F_AND},{"OR",F_OR},{"XOR",F_XOR},{"INVERT",F_INVERT},{"=",F_EQ},{"<",F_LT},{"U<",F_ULT},{"0=",F_ZEROEQ},
 {"@",F_FETCH},{"!",F_STORE},{"C@",F_CFETCH},{"C!",F_CSTORE},{"EMIT",F_EMIT},{".",F_DOT},{"CR",F_CR},{"KEY",F_KEY},
 {">R",F_TOR},{"R>",F_RFROM},{"R@",F_RFETCH},{"I",F_I},{"EXECUTE",F_EXECUTE},{"LSHIFT",F_LSHIFT},{"RSHIFT",F_RSHIFT},{"DEPTH",F_DEPTH}};
 token_used=direct_used=data_used=source_used=control_used=0;count=0;current=-1;
 native_count=origin_id=0;outer_hook=NULL;idle_hook=NULL;transaction_active=have_activation=0;
 observer_active=0;catalog_changed();
 forth_modules_reset();transport_crc=0;
 for(unsigned i=0;i<HASH_BUCKETS;++i)buckets[i]=0;
 selected=FORTH_REFERENCE;fvm_reset();fvm_memory_reset();
#ifndef __ez80__
 fvm_region(0x10000,TOKEN_BYTES,token_code);fvm_region(0x20000,DIRECT_BYTES,direct_code);fvm_region(0x40000,DATA_BYTES,data_space);
#endif
 for(unsigned i=0;i<sizeof(primitives)/sizeof(primitives[0]);++i) {
  begin_word(primitives[i].name,WK_PRIMITIVE);words[count].opcode=primitives[i].op;
  op(primitives[i].op);op(F_EXIT);publish();
 }
 defining("VARIABLE","BASE");base_address=words[count-1].aux;fvm_write_cell(base_address,10);
 forth_eval(": 1+ 1 + ; : 1- 1 - ; : NEGATE 0 SWAP - ; : 2DUP OVER OVER ; : 2DROP DROP DROP ; : CELLS 3 * ; : CELL+ 3 + ; : TRUE -1 ; : FALSE 0 ; : HEX 16 BASE ! ; : DECIMAL 10 BASE ! ;");
}
void forth_set_engine(enum forth_engine engine) {selected=engine;}
void forth_transport_crc(int required) {transport_crc=(unsigned char)(required!=0);}
enum forth_engine forth_engine(void) {return selected;}
const char *forth_last_error(void) {return error_text;}
int forth_compiling(void) {return current>=0;}
size_t forth_code_bytes(enum forth_engine engine) {return engine==FORTH_DIRECT?direct_used:token_used;}
void forth_report(void) {
 print("engine ");print(selected==FORTH_DIRECT?"DIRECT":selected==FORTH_TOKEN?"TOKEN":"C");
 print(" words ");decimal_number(count);print("/");decimal_number(WORDS_MAX);print(" token-bytes ");decimal_number((fcell)token_used);
 print(" direct-bytes ");decimal_number((fcell)direct_used);print(" data-bytes ");decimal_number((fcell)data_used);
 print(" source-bytes ");decimal_number((fcell)source_used);print(" data-peak ");decimal_number(fvm_ds_peak);
 print(" return-peak ");decimal_number(fvm_rs_peak);print("\r\n");
}
fcell forth_get_base(void) {return fvm_read_cell(base_address);}
void forth_set_base(fcell radix) {if(radix>=2&&radix<=36)fvm_write_cell(base_address,radix);}

uint32_t forth_catalog_revision(void) {return catalog_revision;}
unsigned forth_word_count(void) {return count;}
int forth_inspect_word(unsigned index,struct forth_word_info *out) {
 if(!out||index>=count)return 0;
 const struct word *w=&words[index];
 out->name=w->name;out->source=source_space+w->source;
 out->source_length=w->length;out->kind=w->kind;out->origin=w->origin;
 out->xt=(fcell)(index+1);out->token_address=w->token;out->direct_address=w->direct;
 out->token_bytes=w->token_length;out->direct_bytes=w->direct_length;
 out->module=out->module_version=out->target_name=NULL;out->module_crc32=0;
 out->value=out->target_xt=0;out->value_valid=0;
 if(w->origin)forth_module_origin(w->origin,&out->module,&out->module_version,&out->module_crc32);
 if(w->kind==WK_CONSTANT){out->value=w->aux;out->value_valid=1;}
 else if(w->kind==WK_VARIABLE||w->kind==WK_DEFER) {
  fcell saved_error=fvm_error,base=address(data_space);
  /* Only compiler-owned, fully allocated managed cells may be read. */
  if(w->aux>=base&&data_used>=3&&(size_t)(w->aux-base)<=data_used-3) {
   fvm_error=0;out->value=fvm_read_cell(w->aux);out->value_valid=!fvm_error;
  }
  fvm_error=saved_error;
  if(w->kind==WK_DEFER&&out->value_valid) {
   out->target_xt=out->value;
   if(out->target_xt&&out->target_xt<=count)out->target_name=words[out->target_xt-1].name;
  }
 }
 return 1;
}
void forth_inspect_resources(struct forth_resources *out) {
 if(!out)return;
 out->words=count;out->words_max=WORDS_MAX;
 out->token_bytes=token_used;out->token_capacity=TOKEN_BYTES;
 out->direct_bytes=direct_used;out->direct_capacity=DIRECT_BYTES;
 out->data_bytes=data_used;out->data_capacity=DATA_BYTES;
 out->source_bytes=source_used;out->source_capacity=SOURCE_BYTES;out->engine=selected;
}
static void observer_error(char *out,size_t capacity,const char *message) {
 if(!out||!capacity)return;
 size_t i=0;while(i+1<capacity&&message[i]){out[i]=message[i];++i;}out[i]=0;
}
int forth_observe(const char *name,fcell budget,char *error,size_t capacity) {
 if(observer_active||transaction_active||current>=0||fvm_rdepth||fvm_ldepth) {
  observer_error(error,capacity,"observer requires idle VM");return 0;
 }
 if(!budget||budget>FVM_MASK) {
  observer_error(error,capacity,"invalid observer budget");return 0;
 }
 for(unsigned i=0;i<FVM_DS;++i)observer_before.stack[i]=fvm_ds[i];
 observer_before.depth=fvm_depth;observer_before.ip=fvm_ip;
 observer_before.error=fvm_error;observer_before.budget=fvm_budget;
 observer_before.ds_peak=fvm_ds_peak;observer_before.rs_peak=fvm_rs_peak;
 observer_before.engine=selected;observer_before.base=fvm_read_cell(base_address);
 copy(observer_before.error_text,error_text);
 observer_active=1;observer_budget=budget;fvm_depth=0;error_text[0]=0;
 int ok=forth_execute(name);
 if(ok&&fvm_depth) {copy(error_text,"observer leaves stack values");ok=0;}
 observer_error(error,capacity,ok?"":error_text);
 fvm_write_cell(base_address,observer_before.base);
 for(unsigned i=0;i<FVM_DS;++i)fvm_ds[i]=observer_before.stack[i];
 fvm_depth=observer_before.depth;fvm_ip=observer_before.ip;
 fvm_error=observer_before.error;fvm_budget=observer_before.budget;
 fvm_ds_peak=observer_before.ds_peak;fvm_rs_peak=observer_before.rs_peak;
 fvm_rdepth=fvm_ldepth=0;selected=observer_before.engine;
 copy(error_text,observer_before.error_text);observer_active=0;return ok;
}

static void checkpoint_take(struct checkpoint *s) {
 s->token=token_used;s->direct=direct_used;s->data=data_used;s->source=source_used;s->count=count;
 for(unsigned i=0;i<HASH_BUCKETS;++i)s->buckets[i]=buckets[i];
 for(unsigned i=0;i<DATA_BYTES;++i)s->data_bytes[i]=data_space[i];
 s->depth=fvm_depth;s->ip=fvm_ip;s->error=fvm_error;s->budget=fvm_budget;
 s->ds_peak=fvm_ds_peak;s->rs_peak=fvm_rs_peak;s->engine=selected;
 s->base=fvm_read_cell(base_address);
 for(unsigned i=0;i<FVM_DS;++i)s->stack[i]=fvm_ds[i];
}
static void checkpoint_restore(const struct checkpoint *s,int dictionary,int data) {
 if(dictionary) {
  token_used=s->token;direct_used=s->direct;data_used=s->data;source_used=s->source;count=s->count;
  for(unsigned i=0;i<HASH_BUCKETS;++i)buckets[i]=s->buckets[i];
 }
 if(data)for(unsigned i=0;i<DATA_BYTES;++i)data_space[i]=s->data_bytes[i];
 current=-1;control_used=0;fvm_rdepth=fvm_ldepth=0;
 fvm_depth=s->depth;fvm_ip=s->ip;fvm_error=s->error;fvm_budget=s->budget;
 fvm_ds_peak=s->ds_peak;fvm_rs_peak=s->rs_peak;selected=s->engine;
 for(unsigned i=0;i<FVM_DS;++i)fvm_ds[i]=s->stack[i];
}
static int transaction_bindings_valid(void) {
 fcell base=address(data_space);
 for(unsigned i=0;i<count;++i)if(words[i].kind==WK_DEFER) {
  fcell a=words[i].aux,n=fvm_read_cell(a);
  if(fvm_error||n>count)return fail("invalid deferred service binding");
  if(!n&&i<transaction_before.count) {
   if(a<base||a-base>DATA_BYTES-3)return fail("invalid deferred service address");
   size_t offset=(size_t)(a-base);
   if(transaction_before.data_bytes[offset]||transaction_before.data_bytes[offset+1]||transaction_before.data_bytes[offset+2])return fail("cannot unbind an active service during module activation");
  }
 }
 return 1;
}
int forth_transaction_eval(const char *source,const char *test_word,unsigned origin,int commit) {
 char saved_error[96];int ok=0;
 if(transaction_active||current>=0||fvm_rdepth||fvm_ldepth)return forth_transaction_error("module transaction requires idle VM");
 if(!source)return forth_transaction_error("missing module source");
 checkpoint_take(&transaction_before);
 if(!fvm_overlay_begin(address(data_space),DATA_BYTES,data_space))return fail("module overlay unavailable");
 transaction_active=1;transaction_budget=1000000UL;origin_id=origin;selected=FORTH_REFERENCE;
 fvm_reset();
 /* Source packages start in decimal; the caller's interactive BASE persists. */
 fvm_write_cell(base_address,10);
 if(!forth_eval(source))goto done;
 if(current>=0){fail("incomplete module definition");goto done;}
 if(fvm_depth){fail("module initialization leaves stack values");goto done;}
 fvm_overlay_copy(test_data);
 if(test_word&&*test_word) {
  if(!forth_execute(test_word))goto done;
  if(fvm_depth!=1||!fvm_ds[0]){fail("module test must return one true flag");goto done;}
 }
 /* Test writes are discarded; only initializer effects become live. */
 fvm_overlay_restore(test_data);fvm_write_cell(base_address,transaction_before.base);
 if(!transaction_bindings_valid())goto done;
 transaction_words=count-transaction_before.count;transaction_token=token_used-transaction_before.token;
 transaction_direct=direct_used-transaction_before.direct;transaction_data=data_used-transaction_before.data;ok=1;
done:
 copy(saved_error,error_text);transaction_active=0;origin_id=0;
 if(ok&&commit) {
  activation_before=transaction_before;have_activation=1;
  activation_count=count;activation_token=token_used;activation_direct=direct_used;
  activation_data=data_used;activation_source=source_used;
  fvm_overlay_commit();checkpoint_restore(&transaction_before,0,0);
  catalog_changed();
 }else {fvm_overlay_discard();checkpoint_restore(&transaction_before,1,0);}
 copy(error_text,saved_error);return ok;
}
void forth_transaction_forget_rollback(void){have_activation=0;}
void forth_transaction_sizes(unsigned *w,size_t *t,size_t *d,size_t *a){*w=transaction_words;*t=transaction_token;*d=transaction_direct;*a=transaction_data;}
int forth_transaction_rollback(void) {
 if(!have_activation)return forth_transaction_error("no activation checkpoint");
 if(transaction_active||current>=0||fvm_rdepth||fvm_ldepth)return forth_transaction_error("rollback requires idle VM");
 if(count!=activation_count||token_used!=activation_token||direct_used!=activation_direct||data_used!=activation_data||source_used!=activation_source)return forth_transaction_error("rollback blocked by later dictionary definitions");
 checkpoint_restore(&activation_before,1,1);have_activation=0;catalog_changed();return 1;
}
void forth_repl(void) {
 char line[256];unsigned used=0;int overflow=0,cr=0,changed=1;
 print("\r\nVIOS Forth 24 / Agon Light 2\r\nvios> ");
 for(;;) {
  int c=platform_console_getc();
  if(c<0){if(!used&&current<0&&idle_hook){idle_hook(changed);changed=0;}continue;}
  if(c=='\n'&&cr){cr=0;continue;}cr=0;
  if(c=='\r'||c=='\n') {
   cr=c=='\r';print("\r\n");line[used]=0;
   /* Host envelope is consumed before the compiler sees source. No queued
    * marker can become input to a running KEY primitive. */
   char nonce[9];int tagged=used>=10&&line[0]=='@'&&line[9]==' ';
   for(unsigned i=0;tagged&&i<8;++i) {
    char h=line[i+1];if(!((h>='0'&&h<='9')||(h>='A'&&h<='F')))tagged=0;
    nonce[i]=h;
   }
   nonce[8]=0;int success=0;
   const char *request=line+(tagged?10:0);int request_ok=1;
   if(tagged&&(transport_crc||line[10]=='!')) {
    if(used<20||line[10]!='!'||line[19]!=' ') {copy(error_text,"request CRC required");request_ok=0;}
    else {
     uint32_t crc=0;
     for(unsigned i=11;i<19;++i){char h=line[i];unsigned digit=h>='0'&&h<='9'?(unsigned)(h-'0'):h>='A'&&h<='F'?(unsigned)(h-'A'+10):99;
      if(digit>15)request_ok=0;crc=(crc<<4)|digit;
     }
     request=line+20;
     if(!request_ok||crc!=forth_module_crc32(request)){copy(error_text,"request CRC mismatch");request_ok=0;}
    }
   }
   if(overflow) {print("error: input line too long\r\n");rollback();}
   else if(!request_ok||!(success=forth_eval(request))){print("error: ");print(forth_last_error());print("\r\n");}
   if(tagged){print("\r\n@");print(nonce);print("\r\n");}
   if(success)print("ok\r\n");else if(tagged)print("error\r\n");
   used=0;overflow=0;changed=1;print(current>=0?"compile> ":"vios> ");
  }else if(c==8||c==127){if(used&&!overflow){--used;print("\b \b");}}
  else if(c==3){rollback();fvm_reset();used=0;overflow=0;changed=1;print("\r\naborted\r\nvios> ");}
  else if(c>=32&&c<127&&!overflow){if(used+1<sizeof line){line[used++]=(char)c;platform_console_putc((unsigned char)c);}else overflow=1;}
 }
}
