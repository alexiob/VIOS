import pathlib, subprocess, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class TextScreenTests(unittest.TestCase):
 def test_native_dirty_renderer(self):
  binary=ROOT/'build/tests/text-screen';binary.parent.mkdir(parents=True,exist_ok=True)
  subprocess.run(['cc','-std=c99','-pedantic','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-g','-Iinclude','tests/text_screen_native.c','drivers/agon-vdp/text_screen.c','-o',str(binary)],cwd=ROOT,check=True)
  subprocess.run([str(binary)],check=True,capture_output=True,timeout=5)

 def test_pending_is_constant_time_in_actual_target_code(self):
  # Bound target instructions rather than wall-clock timing. The empty check
  # must not inspect either 4,800-cell plane on the 18.432 MHz CPU.
  from test_vios_native_c import LinkedC, TargetImage
  target=ROOT/'build/verification/text-pending';target.mkdir(parents=True,exist_ok=True)
  prefix=ROOT/'.tools/agondev/bin/ez80-none-elf'
  subprocess.run([str(prefix)+'-clang','-target','ez80-none-elf','-mllvm','-z80-gas-style','-mllvm','-z80-print-zero-offset','-std=c99','-ffreestanding','-fno-builtin','-fomit-frame-pointer','-Oz','-Wall','-Wextra','-Werror','-Wa,-march=ez80+full','-nostdinc','-Iinclude','-I.','-isystem',str(ROOT/'.tools/agondev/include'),'-c','drivers/agon-vdp/text_screen.c','-o',str(target/'screen.o')],cwd=ROOT,check=True)
  (target/'stub.s').write_text('.section .text\n.global _image_start\n_image_start:\n ret\n.global _platform_vdp_send\n_platform_vdp_send:\n ret\n')
  subprocess.run([str(prefix)+'-as','-march=ez80+full',str(target/'stub.s'),'-o',str(target/'stub.o')],cwd=ROOT,check=True)
  subprocess.run([str(prefix)+'-ld','-T','boards/agon-light-2/ram.ld','-o',str(target/'screen.elf'),str(target/'stub.o'),str(target/'screen.o'),'-L'+str(ROOT/'.tools/agondev/lib'),'-lagon'],cwd=ROOT,check=True)
  subprocess.run([str(prefix)+'-objcopy','-O','binary',str(target/'screen.elf'),str(target/'screen.bin')],cwd=ROOT,check=True)
  image=TargetImage(target/'screen.elf')
  class PendingCPU(LinkedC):
   def rd(self,address,n=3):
    for name in ('_desired','_painted'):
     begin=self.syms[name]
     assert not (address<begin+9600 and address+n>begin), 'pending scanned a text plane'
    return super().rd(address,n)
  cpu=PendingCPU(image)
  self.assertEqual(cpu.call('_vios_text_pending',budget=64)&0xffffff,0)
  cpu.wr(image.syms['_dirty_cells'],4799)
  self.assertEqual(cpu.call('_vios_text_pending',budget=64)&0xffffff,1)
  class SparseCPU(LinkedC):
   def __init__(self,image):
    super().__init__(image);self.steps=0;self.plane_reads=0;self.row_reads=0
    for name in ('__imulu','__idivu','__ishl','__ladd','__bshru','__bshl','_platform_vdp_send'):
     if name in self.syms:self.hooks[self.syms[name]]=name
   def rd(self,address,n=3):
    for name in ('_desired','_painted'):
     if self.syms[name]<=address<self.syms[name]+9600:self.plane_reads+=1
    if '_dirty_rows' in self.syms and self.syms['_dirty_rows']<=address<self.syms['_dirty_rows']+60:self.row_reads+=1
    return super().rd(address,n)
   def step(self):
    self.steps+=1
    if self.pc and self.ins[self.pc][1].startswith('adc a,'):
     size,operation=self.ins[self.pc];self.pc+=size;left=self.r['a'];right=self.g(operation.split(',')[1]);result=left+right+self.c;self.set('a',result);self.flags(result,8,result>255,bool((~(left^right)&(left^result))&128));return True
    if self.pc and self.ins[self.pc][1].startswith('sub a,'):
     size,operation=self.ins[self.pc];self.pc+=size;left=self.r['a'];right=self.g(operation.split(',')[1]);result=left-right;self.set('a',result);self.flags(result,8,result<0,bool(((left^right)&(left^result))&128));return True
    if self.pc and self.ins[self.pc][1].startswith('mlt '):
     size,operation=self.ins[self.pc];self.pc+=size;pair=operation.split()[1];value=self.g(pair);self.set(pair,(value&255)*((value>>8)&255));return True
    if self.pc and self.ins[self.pc][1]=='scf':
     self.pc+=self.ins[self.pc][0];self.c=True;return True
    if self.pc and self.ins[self.pc][1] in ('push af','pop af'):
     size,operation=self.ins[self.pc];self.pc+=size
     if operation=='push af':
      flags=(128 if self.s else 0)|(64 if self.z else 0)|(4 if self.p else 0)|(1 if self.c else 0)
      self.push((self.r['a']<<8)|flags)
     else:
      value=self.pop();self.set('a',value>>8);self.s=bool(value&128);self.z=bool(value&64);self.p=bool(value&4);self.c=bool(value&1)
     return True
    return super().step()
   def helper(self,name):
    if name=='__imulu':self.set('hl',self.r['hl']*self.r['bc'])
    elif name=='__idivu':self.set('hl',self.r['hl']//self.r['bc'])
    elif name=='__ishl':self.set('hl',self.r['hl']<<self.g('c'))
    elif name=='__bshru':self.set('a',self.r['a']>>self.g('b'))
    elif name=='__bshl':self.set('a',self.r['a']<<self.g('b'))
    elif name=='__ladd':
     result=(self.r['hl']|(self.g('e')<<24))+(self.r['bc']|(self.r['a']<<24))
     self.set('hl',result);self.set('e',result>>24)
    elif name=='_platform_vdp_send':
     start=self.rd(self.r['sp']+3);length=self.rd(self.r['sp']+6)
     self.output.extend(self.mem[start:start+length]);self.clobber()
    else:return super().helper(name)
    self.pc=self.pop()
  # Sparse dirt across 59 clean rows stays bounded. A second case forces
  # scanning the suffix and wrapping back before the starting column.
  for cursor,budget,max_reads in ((80,2000,20),(2,5000,340)):
   sparse=SparseCPU(image)
   for name in ('_desired','_painted'):
    start=image.syms[name];sparse.mem[start:start+9600]=bytes((32,3))*4800
   sparse.wr(image.syms['_paint_cursor'],cursor);sparse.wr(image.syms['_dirty_cells'],1)
   if '_dirty_rows' in image.syms:sparse.wr(image.syms['_dirty_rows'],1,1)
   sparse.wr(image.syms['_desired']+2,ord('X'),1)
   self.assertEqual(sparse.call('_vios_text_render',[8],budget=budget)&0xffffff,8)
   self.assertLessEqual(sparse.plane_reads,max_reads)
   self.assertLessEqual(sparse.row_reads,64)
   self.assertEqual(sparse.output,bytes((17,3,17,128,31,1,0,ord('X'))))
   stats=image.syms['_stats']
   self.assertEqual([sparse.rd(stats+i*4,4) for i in range(4)],[1,1,1,8])
   self.assertEqual(sparse.call('_vios_text_pending',budget=64)&0xffffff,0)
