/* Actual production board C with a 16-byte receive FIFO and byte-level peer.
 * No serial device is opened. UART progress is stepped by register reads.
 */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "platform/console.h"
#include "platform/vdp.h"
#include "drivers/vdp_transport.h"
#include "arch/ez80/uart0.h"
static unsigned char incoming[260],fifo[16],transmitted[512],source[256];
static unsigned next_wire,head,count,overruns,reads,writes,register_reads,timer_reads,wire_length=260;
static int stall_cts,stall_tx;
static int rts;
volatile unsigned ez80_uart0_rx_overruns;
static void arrive(void) {
 if(next_wire<wire_length){
  unsigned char byte=incoming[next_wire++];
  if(count==sizeof fifo)++overruns;
  else{fifo[(head+count)&15]=byte;++count;}
 }
}
static void wire_tick(void) {if(rts)arrive();}
void ez80_uart0_raw_init(void) {}
void ez80_uart0_rx_pause(void) {
 if(rts)arrive(); /* At most one already transmitted character follows CTS. */
 rts=0;
}
void ez80_uart0_rx_resume(void) {rts=1;}
unsigned char ez80_uart0_modem(void) {
 assert(++register_reads<20000);wire_tick(); /* Deadlock fails, not hangs. */
 return stall_cts&&reads<64?0:0x10;
}
unsigned char ez80_uart0_status(void) {
 assert(++register_reads<20000);wire_tick();
 return (unsigned char)((count?1:0)|((!stall_tx||reads>=64)?0x20:0));
}
unsigned ez80_uart0_rx_drain(unsigned char *buffer) {
 ez80_uart0_rx_pause();unsigned n=0;
 while(n<32&&(ez80_uart0_status()&1)){buffer[n]=ez80_uart0_read();++n;}
 return n;
}
void actual_feed(struct vdp_transport *,unsigned char);
void vdp_transport_feed(struct vdp_transport *transport,unsigned char byte) {
 assert(!rts); /* A slow parser must never run with peer transmission enabled. */
 for(unsigned i=0;i<100;++i)wire_tick();
 actual_feed(transport,byte);
}
unsigned char ez80_uart0_read(void) {
 assert(count);unsigned char byte=fifo[head];head=(head+1)&15;--count;++reads;return byte;
}
void ez80_uart0_write(unsigned char value) {
 assert(writes<sizeof transmitted);transmitted[writes++]=value;
}
unsigned short platform_timer_read(void) {++timer_reads;return (unsigned short)(0-timer_reads*1000);}
int main(int argc,char **argv) {
 assert(argc==2);stall_cts=!strcmp(argv[1],"cts");stall_tx=!strcmp(argv[1],"tx");
 if(!strcmp(argv[1],"request")||!strcmp(argv[1],"timeout")){
  const unsigned char command[]={23,0,0xe1};unsigned char reply[4];unsigned actual=99;
  int want_reply=!strcmp(argv[1],"request");wire_length=want_reply?6:0;
  incoming[0]=0xfd;incoming[1]=4;memcpy(incoming+2,"\x01\x80\x00\xff",4);
  platform_console_init();assert(!rts);
  assert(platform_vdp_request(command,sizeof command,0xfd,reply,sizeof reply,&actual)==want_reply);
  assert(!rts&&writes==3&&!memcmp(transmitted,command,3)&&overruns==0);
  assert(actual==(want_reply?4:0));if(want_reply)assert(!memcmp(reply,incoming+2,4));
  puts("resident request opens receive window and leaves RTS paused on success/timeout");return 0;
 }
 for(unsigned i=0;i<256;++i)source[i]=(unsigned char)i;source[255]='\r';
 incoming[0]=0xfe;incoming[1]=240;memcpy(incoming+2,source,240);
 incoming[242]=0xfe;incoming[243]=16;memcpy(incoming+244,source+240,16);
 platform_console_init();
 /* The 128th buffered echo byte forces one atomic 132-byte VDU E0 frame. */
 for(unsigned i=0;i<128;++i)platform_console_putc((unsigned char)('A'+i%26));
 assert(writes==132&&transmitted[0]==23&&transmitted[1]==0&&transmitted[2]==0xe0&&transmitted[3]==128);
 for(unsigned i=0;i<128;++i)assert(transmitted[i+4]==(unsigned char)('A'+i%26));
 for(unsigned i=0;i<256;++i){
  int value;unsigned attempts=0;
  do{value=platform_console_getc();assert(++attempts<1000);}while(value<0);
  if(value!=source[i])fprintf(stderr,"RX mismatch index %u: expected %u got %d, FIFO overruns %u\n",i,source[i],value,overruns);
  assert(value==source[i]);assert(!rts);
 }
 assert(platform_console_getc()==-1&&overruns==0&&reads==260);
 assert(timer_reads==0); /* TX progress does not depend on timer initialization. */
 assert(rts);ez80_uart0_rx_overruns=3;assert(platform_console_dropped()==3);
 puts("resident console flush preserves all 256 input bytes and frame atomicity");return 0;
}
