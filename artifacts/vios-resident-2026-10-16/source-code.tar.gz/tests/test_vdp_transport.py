import pathlib,subprocess,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class VdpTransportTests(unittest.TestCase):
 def test_native_packet_parser(self):
  self.assertTrue((ROOT/'drivers/agon-vdp/transport.c').exists(),'VDP transport missing')
  binary=ROOT/'build/tests/vdp-transport';binary.parent.mkdir(parents=True,exist_ok=True)
  subprocess.run(['cc','-std=c99','-pedantic','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-g','-Iinclude','tests/vdp_transport_native.c','drivers/agon-vdp/transport.c','-o',str(binary)],cwd=ROOT,check=True)
  subprocess.run([str(binary)],check=True,capture_output=True,timeout=5)
