#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "vios/workbench.h"
static char cells[60][80];
static unsigned char attributes[60][80];
void vios_text_begin_frame(void){memset(cells,' ',sizeof cells);memset(attributes,3,sizeof attributes);}
void vios_text_put(unsigned x,unsigned y,const char *s,size_t n,unsigned fg,unsigned bg){assert(y<60&&x+n<=80);memcpy(cells[y]+x,s,n);memset(attributes[y]+x,(int)(fg|(bg<<4)),n);}
void platform_console_putc(unsigned char c){(void)c;}
int platform_console_getc(void){return -1;}
void platform_console_init(void){}
const char *platform_identity(void){return "test";}
void platform_restart(void){}
static struct vios_workbench_status status(void){struct vios_workbench_status s;vios_workbench_status(&s);return s;}
static void fresh(void){forth_init();vios_workbench_init();vios_workbench_open();}
static void install(const char *name,const char *src){assert(forth_module_stage(name,"1",NULL,0,src,NULL));assert(forth_module_activate(name));}
static fcell result(const char *src){assert(forth_eval(src));return fvm_pop();}
static void editor(void){
 fresh();const char *src="\\ exact\r\n\t: VALUE 22 ;\n";install("sample",src);
 assert(vios_workbench_edit("sample",0));assert(strcmp(vios_workbench_source(),src)==0);
 struct vios_workbench_status s=status();assert(s.activated&&!s.dirty&&s.length==strlen(src));
 assert(vios_workbench_patch(s.revision,0,0," ",1));assert(status().dirty);
 assert(!vios_workbench_patch(s.revision,0,0,"x",1));assert(strstr(vios_workbench_error(),"stale"));
 char old[4097];strcpy(old,vios_workbench_source());
 assert(!vios_workbench_patch(status().revision,9000,0,"x",1));assert(!strcmp(old,vios_workbench_source()));
 assert(!vios_workbench_patch(status().revision,0,0,"\033",1));assert(!strcmp(old,vios_workbench_source()));
 assert(!vios_workbench_patch(status().revision,0,0,"\0",1));
 assert(!vios_workbench_new("other","1",0));assert(!strcmp(old,vios_workbench_source()));
 assert(vios_workbench_undo(status().revision));assert(!strcmp(src,vios_workbench_source()));assert(!status().dirty);
 assert(!vios_workbench_undo(status().revision));
 vios_workbench_close();assert(!vios_workbench_active());vios_workbench_open();assert(!strcmp(src,vios_workbench_source()));
 assert(vios_workbench_new("other","1",1));char full[4096];memset(full,' ',sizeof full);
 assert(vios_workbench_patch(status().revision,0,0,full,sizeof full));
 assert(!vios_workbench_patch(status().revision,4096,0,"x",1));assert(status().length==4096);
 assert(vios_workbench_undo(status().revision));assert(status().length==0);
 assert(vios_workbench_patch(status().revision,0,0,"abc\ndef",7));
 assert(vios_workbench_key(9,0)==VIOS_WB_NONE); /* editor focus */
 vios_workbench_key(VIOS_WB_HOME,0);assert(status().cursor==4);
 vios_workbench_key(8,0);assert(!strcmp(vios_workbench_source(),"abcdef"));
 vios_workbench_key(VIOS_WB_HOME,0);vios_workbench_key(VIOS_WB_DELETE,0);assert(!strcmp(vios_workbench_source(),"bcdef"));
 vios_workbench_key('A',2|16|32);assert(!strcmp(vios_workbench_source(),"Abcdef"));
 vios_workbench_key('X',1);assert(!strcmp(vios_workbench_source(),"Abcdef"));
 assert(vios_workbench_key(VIOS_WB_F5,0)==VIOS_WB_STAGE);
 assert(vios_workbench_key(VIOS_WB_F6,0)==VIOS_WB_ACTIVATE);
 assert(vios_workbench_key(VIOS_WB_F7,0)==VIOS_WB_SAVE);
 assert(vios_workbench_key(VIOS_WB_F10,0)==VIOS_WB_CLOSED);
}
static void viewport(void){
 fresh();assert(vios_workbench_new("long","1",0));char line[101];memset(line,'a',100);line[100]='Z';
 assert(vios_workbench_patch(status().revision,0,0,line,sizeof line));
 vios_workbench_key(9,0);vios_workbench_compose();
 assert(cells[18][78]=='Z'&&attributes[18][79]==32);
 assert(vios_workbench_key(VIOS_WB_HOME,0)==VIOS_WB_NONE);vios_workbench_compose();
 assert(cells[18][26]=='a'&&attributes[18][26]==32);
}
static void transaction(void){
 fresh();assert(forth_eval("DEFER SERVICE : OLD 11 ; ' OLD IS SERVICE VARIABLE X 7 X !"));
 install("provider",": VALUE 22 ; ' VALUE IS SERVICE");
 assert(vios_workbench_edit("provider",0));assert(vios_workbench_can_save(status().revision));
 assert(vios_workbench_mark_saved(status().revision));assert(status().saved);
 assert(vios_workbench_set_metadata(status().revision,"2","",NULL,0));
 const char *bad=": VALUE 33 ; 99 X ! ' VALUE IS SERVICE MISSING";
 assert(vios_workbench_patch(status().revision,0,status().length,bad,strlen(bad)));
 assert(forth_eval("HEX"));assert(fvm_push(123));
 assert(!vios_workbench_stage(status().revision));assert(fvm_depth==1&&fvm_pop()==123&&forth_get_base()==16);
 assert(result("SERVICE")==22&&result("X @")==7);assert(!strcmp(vios_workbench_source(),bad));
 const char *good=": VALUE 33 ; ' VALUE IS SERVICE";
 assert(vios_workbench_patch(status().revision,0,status().length,good,strlen(good)));
 assert(vios_workbench_stage(status().revision));assert(status().staged);
 assert(result("SERVICE")==22);assert(!vios_workbench_can_save(status().revision));
 assert(vios_workbench_activate(status().revision));assert(result("SERVICE")==33);
 assert(vios_workbench_can_save(status().revision));assert(vios_workbench_mark_saved(status().revision));
 assert(!status().dirty&&status().saved);
 assert(vios_workbench_set_metadata(status().revision,"3","",NULL,0));
 assert(!vios_workbench_stage(status().revision));assert(strstr(vios_workbench_error(),"two module"));
 assert(result("SERVICE")==33);
}
static void aliased_metadata(void){
 fresh();assert(vios_workbench_new("APP","1",0));
 assert(vios_workbench_set_metadata(status().revision,"V2","CHECK",NULL,0));
 struct vios_workbench_status before=status();
 assert(vios_workbench_set_metadata(before.revision,before.test_word,before.version,NULL,0));
 assert(!strcmp(status().version,"CHECK")&&!strcmp(status().test_word,"V2"));
 before=status();assert(vios_workbench_new(before.version,before.module,1));
 assert(!strcmp(status().module,"CHECK")&&!strcmp(status().version,"APP"));
}
static void activation_failure(void){
 fresh();assert(forth_eval("VARIABLE X 7 X ! DEFER SERVICE : OLD 11 ; ' OLD IS SERVICE"));
 assert(vios_workbench_new("guarded","1",0));
 const char *src=": VALUE 22 ; ' VALUE IS SERVICE : CHECK X @ 7 = ;";
 assert(vios_workbench_patch(status().revision,0,0,src,strlen(src)));
 assert(vios_workbench_set_metadata(status().revision,"1","CHECK",NULL,0));
 assert(vios_workbench_stage(status().revision));
 assert(forth_eval("9 X ! HEX"));assert(fvm_push(123));
 assert(!vios_workbench_activate(status().revision));
 assert(fvm_depth==1&&fvm_pop()==123&&forth_get_base()==16);
 assert(result("SERVICE")==11&&result("X @")==9);
 assert(status().staged&&!status().activated&&!strcmp(vios_workbench_source(),src));
 char error[128];strcpy(error,vios_workbench_error());
 assert(!forth_eval("MISSING"));assert(!strcmp(vios_workbench_error(),error));
 assert(forth_eval("7 X !"));assert(vios_workbench_activate(status().revision));
 assert(result("SERVICE")==22);
}
static void pending_identity(void){
 fresh();install("base",": BASEWORD 9 ;");install("other",": OTHERWORD 8 ;");
 struct forth_module_dependency first={"base",forth_module_crc32(": BASEWORD 9 ;")};
 struct forth_module_dependency second={"other",forth_module_crc32(": OTHERWORD 8 ;")};
 assert(vios_workbench_new("client","1",0));const char *src=": CLIENT 7 ;";
 assert(vios_workbench_patch(status().revision,0,0,src,strlen(src)));
 assert(vios_workbench_set_metadata(status().revision,"1","",&first,1));
 assert(vios_workbench_stage(status().revision));struct forth_module_dependency pending;
 assert(forth_module_pending_dependency_at(0,&pending));assert(!strcmp(pending.name,"base"));
 assert(!forth_module_pending_dependency_at(1,&pending));assert(!forth_module_pending_dependency_at(0,NULL));
 assert(forth_module_discard());assert(!forth_module_pending_dependency_at(0,&pending));
 assert(forth_module_stage("client","1",&second,1,src,NULL));
 assert(!status().staged);assert(!vios_workbench_activate(status().revision));
 assert(!forth_find_xt("CLIENT"));assert(vios_workbench_patch(status().revision,0,0," ",1));
 assert(forth_module_pending_dependency_at(0,&pending));assert(!strcmp(pending.name,"other"));
 assert(forth_module_discard());assert(vios_workbench_stage(status().revision));assert(vios_workbench_activate(status().revision));
}
static void copied_dependencies(void){
 fresh();install("base",": BASEWORD 9 ;");
 struct forth_module_dependency dep={"base",forth_module_crc32(": BASEWORD 9 ;")};
 assert(forth_module_stage("client","1",&dep,1,": CLIENT BASEWORD ;",NULL));assert(forth_module_activate("client"));
 assert(vios_workbench_edit("client",0));assert(status().dependency_count==1);
 assert(!strcmp(status().dependencies[0].name,"base"));
 char name[32]="base",version[32]="2",test[32]="";dep.name=name;
 assert(vios_workbench_set_metadata(status().revision,version,test,&dep,1));
 strcpy(name,"damaged");strcpy(version,"bad");
 assert(!strcmp(status().version,"2")&&!strcmp(status().dependencies[0].name,"base"));
 assert(vios_workbench_stage(status().revision));assert(vios_workbench_activate(status().revision));
 assert(vios_workbench_can_save(status().revision));
 assert(forth_module_rollback("client"));assert(!status().activated&&!status().saved);
 assert(!vios_workbench_can_save(status().revision));
}
static void browsing(void){
 fresh();install("alpha",": APP 42 ;");assert(vios_workbench_browse(VIOS_WB_MODULES,NULL));
 assert(status().browser_count==1);assert(vios_workbench_select_module("alpha"));
 vios_workbench_key(VIOS_WB_RIGHT,0);assert(status().browser==VIOS_WB_WORDS&&status().browser_count==1);
 vios_workbench_key(VIOS_WB_LEFT,0);assert(status().browser==VIOS_WB_MODULES);
 assert(vios_workbench_browse(VIOS_WB_WORDS,"alpha"));assert(status().browser_count==1);
 struct forth_word_info word;assert(vios_workbench_selected_word(&word));assert(!strcmp(word.name,"APP"));
 assert(vios_workbench_edit("alpha",0));assert(fvm_push(888));assert(forth_eval("HEX"));
 vios_workbench_compose();assert(fvm_depth==1&&fvm_ds[0]==888&&forth_get_base()==16);
 assert(!memcmp(cells[0],"VIOS",4));
 assert(vios_workbench_set_metadata(status().revision,"2","",NULL,0));
 assert(forth_eval(": OUTSIDE 1 ;"));assert(!vios_workbench_stage(status().revision));
 assert(strstr(vios_workbench_error(),"catalog"));
}
int main(void){editor();viewport();transaction();aliased_metadata();activation_failure();pending_identity();copied_dependencies();browsing();puts("Workbench checks passed");return 0;}
