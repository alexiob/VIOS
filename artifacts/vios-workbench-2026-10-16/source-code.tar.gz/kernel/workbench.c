/* Portable, bounded workbench model. All entry points run on the idle VM owner. */
#include <string.h>
#include "vios/workbench.h"
#include "vios/text_screen.h"
static struct {
 char source[VIOS_WB_SOURCE_MAX+1],undo[VIOS_WB_SOURCE_MAX+1];
 char module[32],version[32],test[32],error[128],selection[32],filter[32];
 char dep_names[FORTH_MODULE_DEPS_MAX][32];
 struct forth_module_dependency deps[FORTH_MODULE_DEPS_MAX];
 unsigned length,cursor,undo_length,undo_cursor,dep_count,selected,scroll;
 uint32_t revision,catalog,staged_revision;
 int open,has_draft,dirty,staged,activated,saved,undo_valid;
 int undo_dirty,undo_activated,undo_saved;
 enum vios_workbench_browser browser;
 enum vios_workbench_focus focus;
} wb;
static void bounded_copy(char *out,const char *s,size_t max){size_t n=0;if(s)while(s[n]&&n+1<max){out[n]=s[n];++n;}out[n]=0;}
static int fail(const char *s){bounded_copy(wb.error,s,sizeof wb.error);return 0;}
static int okay(void){wb.error[0]=0;return 1;}
static int identifier(const char *s,int empty){size_t n=0;if(!s)return empty;if(!*s)return empty;for(;s[n];++n)if(n>=31||(unsigned char)s[n]<33||(unsigned char)s[n]>126)return 0;return 1;}
static int module_info(const char *name,struct forth_module_info *out){for(unsigned i=0;i<forth_module_count();++i)if(forth_module_info(i,out)&&!strcmp(name,out->name))return 1;return 0;}
static int matches(const struct forth_module_info *m,const char *source){
 if(!source||strcmp(m->name,wb.module)||strcmp(m->version,wb.version)||strcmp(m->test_word,wb.test)||strcmp(source,wb.source)||m->dependency_count!=wb.dep_count)return 0;
 for(unsigned i=0;i<wb.dep_count;++i){struct forth_module_dependency d;
  if(!forth_module_dependency_at(wb.module,0,i,&d)||strcmp(d.name,wb.deps[i].name)||d.source_crc32!=wb.deps[i].source_crc32)return 0;}
 return 1;
}
static int exact_active(void){struct forth_module_info m;return wb.activated&&module_info(wb.module,&m)&&matches(&m,forth_module_source(wb.module,0));}
static int pending_matches(void){struct forth_module_info m;
 if(!forth_module_pending_info(&m)||strcmp(m.name,wb.module)||strcmp(m.version,wb.version)||strcmp(m.test_word,wb.test)||m.dependency_count!=wb.dep_count)return 0;
 for(unsigned i=0;i<wb.dep_count;++i){struct forth_module_dependency d;
  if(!forth_module_pending_dependency_at(i,&d)||strcmp(d.name,wb.deps[i].name)||d.source_crc32!=wb.deps[i].source_crc32)return 0;}
 const char *s=forth_module_pending_source();return s&&!strcmp(s,wb.source);
}
static void invalidate(void){if(wb.staged&&pending_matches())forth_module_discard();wb.staged=0;wb.activated=0;wb.saved=0;}
static int revision(uint32_t expected){if(!wb.has_draft)return fail("no module draft");if(expected!=wb.revision)return fail("stale draft revision");if(wb.revision==UINT32_MAX)return fail("draft revision exhausted");return 1;}
static void snapshot(void){memcpy(wb.undo,wb.source,wb.length+1);wb.undo_length=wb.length;wb.undo_cursor=wb.cursor;wb.undo_dirty=wb.dirty;wb.undo_activated=wb.activated;wb.undo_saved=wb.saved;wb.undo_valid=1;}
static unsigned browser_count(void){
 if(wb.browser==VIOS_WB_MODULES)return forth_module_count();
 if(!wb.filter[0])return forth_word_count();
 unsigned count=0;for(unsigned i=0;i<forth_word_count();++i){struct forth_word_info w;if(forth_inspect_word(i,&w)&&(!wb.filter[0]||(w.module&&!strcmp(w.module,wb.filter))))++count;}return count;
}
static int browser_item(unsigned row,unsigned *absolute,const char **name){
 if(wb.browser==VIOS_WB_MODULES){struct forth_module_info m;if(!forth_module_info(row,&m))return 0;*absolute=row;*name=m.name;return 1;}
 if(!wb.filter[0]){struct forth_word_info w;if(!forth_inspect_word(row,&w))return 0;*absolute=row;*name=w.name;return 1;}
 unsigned count=0;for(unsigned i=0;i<forth_word_count();++i){struct forth_word_info w;if(!forth_inspect_word(i,&w)||(wb.filter[0]&&(!w.module||strcmp(w.module,wb.filter))))continue;
  if(count++==row){*absolute=i;*name=w.name;return 1;}}
 return 0;
}
static void refresh_selection(void){unsigned n=browser_count(),absolute;const char *name;
 if(wb.selected>=n)wb.selected=n?n-1:0;
 if(browser_item(wb.selected,&absolute,&name))bounded_copy(wb.selection,name,sizeof wb.selection);else wb.selection[0]=0;
 if(wb.selected<wb.scroll)wb.scroll=wb.selected;if(wb.selected>=wb.scroll+53)wb.scroll=wb.selected-52;
}
void vios_workbench_init(void){memset(&wb,0,sizeof wb);wb.revision=1;wb.catalog=forth_catalog_revision();}
void vios_workbench_open(void){wb.open=1;refresh_selection();}
void vios_workbench_close(void){wb.open=0;}
int vios_workbench_active(void){return wb.open;}
const char *vios_workbench_error(void){return wb.error;}
void vios_workbench_note_error(const char *message){bounded_copy(wb.error,message,sizeof wb.error);}
const char *vios_workbench_source(void){return wb.source;}
void vios_workbench_status(struct vios_workbench_status *out){if(!out)return;refresh_selection();
 out->module=wb.module;out->version=wb.version;out->test_word=wb.test;out->error=wb.error;out->selection=wb.selection;out->filter=wb.filter;out->dependencies=wb.deps;out->dependency_count=wb.dep_count;
 out->length=wb.length;out->cursor=wb.cursor;out->selection_index=wb.selected;out->browser_count=browser_count();out->revision=wb.revision;out->catalog_revision=forth_catalog_revision();
 out->open=wb.open;out->has_draft=wb.has_draft;out->dirty=wb.dirty;out->staged=wb.staged&&wb.staged_revision==wb.revision&&pending_matches();out->activated=exact_active();out->saved=wb.saved&&out->activated;out->undo_available=wb.undo_valid;out->browser=wb.browser;out->focus=wb.focus;
}
int vios_workbench_browse(enum vios_workbench_browser browser,const char *filter){if(browser!=VIOS_WB_MODULES&&browser!=VIOS_WB_WORDS)return fail("invalid browser");if(!identifier(filter,1))return fail("invalid module filter");wb.browser=browser;bounded_copy(wb.filter,filter,sizeof wb.filter);wb.selected=wb.scroll=0;refresh_selection();return okay();}
int vios_workbench_select_word(unsigned index){struct forth_word_info w;if(!forth_inspect_word(index,&w))return fail("word index out of range");wb.browser=VIOS_WB_WORDS;wb.filter[0]=0;wb.selected=index;refresh_selection();return okay();}
int vios_workbench_select_module(const char *name){struct forth_module_info m;if(!name)return fail("missing module");for(unsigned i=0;i<forth_module_count();++i)if(forth_module_info(i,&m)&&!strcmp(name,m.name)){wb.browser=VIOS_WB_MODULES;wb.selected=i;refresh_selection();return okay();}return fail("module not found");}
int vios_workbench_selected_word(struct forth_word_info *out){unsigned absolute;const char *name;refresh_selection();return wb.browser==VIOS_WB_WORDS&&browser_item(wb.selected,&absolute,&name)&&forth_inspect_word(absolute,out);}
static int replace_ready(int discard){if(wb.has_draft&&wb.dirty&&!discard)return fail("dirty draft requires explicit discard");if(wb.revision==UINT32_MAX)return fail("draft revision exhausted");return 1;}
int vios_workbench_edit(const char *name,int discard){struct forth_module_info m;if(!name||!module_info(name,&m))return fail("module not found");if(!replace_ready(discard))return 0;
 const char *source=forth_module_source(name,0);if(!source||m.source_length>VIOS_WB_SOURCE_MAX)return fail("module source unavailable or too large");
 invalidate();bounded_copy(wb.module,m.name,sizeof wb.module);bounded_copy(wb.version,m.version,sizeof wb.version);bounded_copy(wb.test,m.test_word,sizeof wb.test);memcpy(wb.source,source,m.source_length+1);wb.length=m.source_length;wb.cursor=0;wb.dep_count=m.dependency_count;
 for(unsigned i=0;i<wb.dep_count;++i){struct forth_module_dependency d;forth_module_dependency_at(name,0,i,&d);bounded_copy(wb.dep_names[i],d.name,32);wb.deps[i].name=wb.dep_names[i];wb.deps[i].source_crc32=d.source_crc32;}
 wb.has_draft=1;wb.dirty=0;wb.activated=1;wb.saved=0;wb.undo_valid=0;++wb.revision;wb.catalog=forth_catalog_revision();return okay();
}
int vios_workbench_new(const char *name,const char *version_name,int discard){if(!identifier(name,0)||!identifier(version_name,0))return fail("invalid module name/version");if(!replace_ready(discard))return 0;char saved_name[32],saved_version[32];bounded_copy(saved_name,name,32);bounded_copy(saved_version,version_name,32);invalidate();bounded_copy(wb.module,saved_name,32);bounded_copy(wb.version,saved_version,32);wb.source[0]=wb.test[0]=0;wb.length=wb.cursor=wb.dep_count=0;wb.has_draft=wb.dirty=1;wb.undo_valid=0;++wb.revision;wb.catalog=forth_catalog_revision();return okay();}
int vios_workbench_patch(uint32_t expected,size_t offset,size_t remove,const char *bytes,size_t length){
 if(!revision(expected))return 0;if(offset>wb.length||remove>wb.length-offset)return fail("patch range out of bounds");if(length>VIOS_WB_SOURCE_MAX-(wb.length-remove))return fail("draft exceeds 4096 bytes");if(length&&!bytes)return fail("missing patch bytes");
 for(size_t i=0;i<length;++i){unsigned char c=(unsigned char)bytes[i];if((c<32&&c!='\t'&&c!='\r'&&c!='\n')||c>126)return fail("draft source must be ASCII without control bytes");}
 /* Reject aliasing draft slices rather than expose memmove-order surprises. */
 if(length){for(unsigned i=0;i<=wb.length;++i)if(bytes==wb.source+i)return fail("patch bytes alias draft");}
 snapshot();invalidate();memmove(wb.source+offset+length,wb.source+offset+remove,wb.length-offset-remove+1);if(length)memcpy(wb.source+offset,bytes,length);wb.length=(unsigned)(wb.length-remove+length);wb.cursor=(unsigned)(offset+length);wb.dirty=1;++wb.revision;return okay();
}
int vios_workbench_undo(uint32_t expected){if(!revision(expected))return 0;if(!wb.undo_valid)return fail("no undo snapshot");invalidate();memcpy(wb.source,wb.undo,wb.undo_length+1);wb.length=wb.undo_length;wb.cursor=wb.undo_cursor;wb.dirty=wb.undo_dirty;wb.activated=wb.undo_activated;wb.saved=wb.undo_saved;wb.undo_valid=0;++wb.revision;return okay();}
int vios_workbench_set_metadata(uint32_t expected,const char *version_name,const char *test,const struct forth_module_dependency *deps,unsigned count){
 if(!revision(expected))return 0;if(!identifier(version_name,0)||!identifier(test,1))return fail("invalid version/test word");if(count>FORTH_MODULE_DEPS_MAX||(count&&!deps))return fail("dependency capacity exceeded");
 for(unsigned i=0;i<count;++i){if(!identifier(deps[i].name,0))return fail("invalid dependency name");for(unsigned j=0;j<i;++j)if(!strcmp(deps[i].name,deps[j].name))return fail("duplicate module dependency");}
 char saved_version[32],saved_test[32],saved_names[FORTH_MODULE_DEPS_MAX][32];uint32_t saved_crcs[FORTH_MODULE_DEPS_MAX];
 bounded_copy(saved_version,version_name,32);bounded_copy(saved_test,test,32);for(unsigned i=0;i<count;++i){bounded_copy(saved_names[i],deps[i].name,32);saved_crcs[i]=deps[i].source_crc32;}
 invalidate();bounded_copy(wb.version,saved_version,32);bounded_copy(wb.test,saved_test,32);wb.dep_count=count;for(unsigned i=0;i<count;++i){bounded_copy(wb.dep_names[i],saved_names[i],32);wb.deps[i].name=wb.dep_names[i];wb.deps[i].source_crc32=saved_crcs[i];}
 wb.undo_valid=0;wb.dirty=1;++wb.revision;return okay();
}
static int catalog_valid(void){return wb.catalog==forth_catalog_revision()?1:fail("live catalog changed; reload draft before stage/activate");}
int vios_workbench_stage(uint32_t expected){struct forth_module_info pending;if(!revision(expected)||!catalog_valid())return 0;if(wb.staged&&wb.staged_revision==expected&&pending_matches())return okay();
 if(forth_module_pending_info(&pending))return fail("another module is pending; discard or activate it first");
 if(!forth_module_stage(wb.module,wb.version,wb.deps,wb.dep_count,wb.source,wb.test)){bounded_copy(wb.error,forth_last_error(),sizeof wb.error);forth_module_discard();wb.staged=0;return 0;}
 wb.staged=1;wb.staged_revision=wb.revision;return okay();
}
int vios_workbench_activate(uint32_t expected){if(!revision(expected)||!catalog_valid())return 0;if(!wb.staged||wb.staged_revision!=expected||!pending_matches())return fail("draft must be staged at this revision");
 if(!forth_module_activate(wb.module))return fail(forth_last_error());wb.staged=0;wb.activated=1;wb.saved=0;wb.catalog=forth_catalog_revision();return okay();
}
int vios_workbench_can_save(uint32_t expected){struct forth_module_info m;if(!revision(expected))return 0;if(!wb.activated||!module_info(wb.module,&m)||!matches(&m,forth_module_source(wb.module,0)))return fail("save requires the exact active draft");return okay();}
int vios_workbench_mark_saved(uint32_t expected){if(!vios_workbench_can_save(expected))return 0;wb.saved=1;wb.dirty=0;return okay();}
static unsigned line_start(unsigned cursor){while(cursor&&wb.source[cursor-1]!='\n'&&wb.source[cursor-1]!='\r')--cursor;return cursor;}
static unsigned line_end(unsigned cursor){while(cursor<wb.length&&wb.source[cursor]!='\n'&&wb.source[cursor]!='\r')++cursor;return cursor;}
enum vios_workbench_request vios_workbench_key(unsigned code,unsigned modifiers){
 if(!wb.open)return VIOS_WB_NONE;if(code==VIOS_WB_F10){vios_workbench_close();return VIOS_WB_CLOSED;}if(code==VIOS_WB_F5)return VIOS_WB_STAGE;if(code==VIOS_WB_F6)return VIOS_WB_ACTIVATE;if(code==VIOS_WB_F7)return VIOS_WB_SAVE;
 if(code==VIOS_WB_F8){vios_workbench_undo(wb.revision);return VIOS_WB_NONE;}if(code==9){wb.focus=wb.focus==VIOS_WB_BROWSER?VIOS_WB_EDITOR:VIOS_WB_BROWSER;return VIOS_WB_NONE;}if(modifiers&(VIOS_WB_MOD_CTRL|VIOS_WB_MOD_LALT|VIOS_WB_MOD_RALT|VIOS_WB_MOD_GUI))return VIOS_WB_NONE;
 if(wb.focus==VIOS_WB_BROWSER){refresh_selection();
  if(code==VIOS_WB_RIGHT&&wb.browser==VIOS_WB_MODULES){char filter[32];bounded_copy(filter,wb.selection,32);vios_workbench_browse(VIOS_WB_WORDS,filter);return VIOS_WB_NONE;}
  if(code==VIOS_WB_LEFT&&wb.browser==VIOS_WB_WORDS){char module[32];bounded_copy(module,wb.filter,32);vios_workbench_browse(VIOS_WB_MODULES,NULL);if(module[0])vios_workbench_select_module(module);return VIOS_WB_NONE;}
  if(code==VIOS_WB_UP&&wb.selected)--wb.selected;if(code==VIOS_WB_DOWN&&wb.selected+1<browser_count())++wb.selected;if(code==VIOS_WB_HOME)wb.selected=0;if(code==VIOS_WB_END&&browser_count())wb.selected=browser_count()-1;
  refresh_selection();if(code==13||code==10){if(wb.browser==VIOS_WB_MODULES)vios_workbench_edit(wb.selection,0);else {struct forth_word_info w;if(vios_workbench_selected_word(&w)){if(w.module)vios_workbench_edit(w.module,0);else fail("kernel words are read-only");}}}return VIOS_WB_NONE;}
 if(!wb.has_draft)return VIOS_WB_NONE;
 if(code==VIOS_WB_LEFT){if(wb.cursor)--wb.cursor;}else if(code==VIOS_WB_RIGHT){if(wb.cursor<wb.length)++wb.cursor;}
 else if(code==VIOS_WB_HOME)wb.cursor=line_start(wb.cursor);else if(code==VIOS_WB_END)wb.cursor=line_end(wb.cursor);
 else if(code==VIOS_WB_UP){unsigned start=line_start(wb.cursor),column=wb.cursor-start;if(start){unsigned end=start-1;if(end&&wb.source[end]=='\n'&&wb.source[end-1]=='\r')--end;unsigned previous=line_start(end);wb.cursor=previous+column;if(wb.cursor>end)wb.cursor=end;}}
 else if(code==VIOS_WB_DOWN){unsigned column=wb.cursor-line_start(wb.cursor),end=line_end(wb.cursor);if(end<wb.length){unsigned next=end+1;if(wb.source[end]=='\r'&&next<wb.length&&wb.source[next]=='\n')++next;wb.cursor=next+column;unsigned stop=line_end(next);if(wb.cursor>stop)wb.cursor=stop;}}
 else if(code==8||code==127){if(wb.cursor)vios_workbench_patch(wb.revision,wb.cursor-1,1,NULL,0);}
 else if(code==VIOS_WB_DELETE){if(wb.cursor<wb.length)vios_workbench_patch(wb.revision,wb.cursor,1,NULL,0);}
 else if(code==13||code==10){vios_workbench_patch(wb.revision,wb.cursor,0,"\n",1);}
 else if(code>=32&&code<=126){char c=(char)code;vios_workbench_patch(wb.revision,wb.cursor,0,&c,1);}return VIOS_WB_NONE;
}
static void text(unsigned x,unsigned y,const char *s,unsigned width,unsigned fg){size_t n=strlen(s);if(n>width)n=width;vios_text_put(x,y,s,n,fg,0);}
static void number(unsigned x,unsigned y,unsigned value,unsigned width){char buf[16];unsigned n=0;do{buf[n++]=(char)('0'+value%10);value/=10;}while(value&&n<sizeof buf);char out[16];for(unsigned i=0;i<n;++i)out[i]=buf[n-1-i];if(n>width)n=width;vios_text_put(x,y,out,n,3,0);}
void vios_workbench_compose(void){
 vios_text_begin_frame();if(!wb.open)return;refresh_selection();text(0,0,"VIOS  TEXT WORKBENCH",80,2);text(0,1,wb.browser==VIOS_WB_MODULES?"MODULES":"WORDS",25,2);
 if(wb.browser==VIOS_WB_WORDS&&wb.filter[0]){
  unsigned index=0,row=0;for(unsigned i=0;i<forth_word_count()&&row<53;++i){struct forth_word_info w;
   if(!forth_inspect_word(i,&w)||!w.module||strcmp(w.module,wb.filter))continue;
   if(index>=wb.scroll){text(0,row+2,w.name,25,index==wb.selected?2:3);++row;}++index;}
 }else for(unsigned row=0;row<53;++row){unsigned absolute;const char *name;if(browser_item(wb.scroll+row,&absolute,&name))text(0,row+2,name,25,wb.scroll+row==wb.selected?2:3);}
 for(unsigned y=1;y<56;++y)text(25,y,"|",1,2);
 text(26,1,"INSPECTOR",54,2);struct forth_word_info word;
 if(vios_workbench_selected_word(&word)){text(26,2,word.name,54,3);text(26,3,word.module?word.module:"kernel / read-only",54,3);text(26,4,word.module_version?word.module_version:"",54,3);text(26,5,"XT:",4,3);number(30,5,(unsigned)word.xt,16);text(26,6,"Token bytes:",16,3);number(42,6,word.token_bytes,12);text(26,7,"Direct bytes:",16,3);number(42,7,word.direct_bytes,12);if(word.target_name){text(26,8,"DEFER ->",9,3);text(35,8,word.target_name,45,3);}if(word.value_valid){text(26,9,"Value:",8,3);number(34,9,(unsigned)word.value,16);}}
 else if(wb.selection[0]){struct forth_module_info m;if(module_info(wb.selection,&m)){text(26,2,m.name,54,3);text(26,3,m.version,54,3);text(26,4,"Source bytes:",16,3);number(42,4,m.source_length,12);text(26,5,"Dependencies:",16,3);number(42,5,m.dependency_count,12);}}
 text(26,11,"DS:",4,3);number(30,11,(unsigned)fvm_depth,10);text(42,11,"BASE:",6,3);number(48,11,(unsigned)forth_get_base(),10);
 for(unsigned i=0;i<3&&i<fvm_depth;++i)number(26+i*17,12,(unsigned)fvm_ds[fvm_depth-1-i],16);
 struct forth_resources resources;forth_inspect_resources(&resources);
 text(26,14,"Words:",8,3);number(34,14,resources.words,8);text(44,14,"Data:",7,3);number(51,14,(unsigned)resources.data_bytes,9);
 text(26,16,wb.focus==VIOS_WB_EDITOR?"SOURCE [focused]":"SOURCE",54,2);text(26,17,wb.has_draft?wb.module:"Select module and Enter to edit",54,3);
 unsigned current_line=0;for(unsigned i=0;i<wb.cursor;++i)if(wb.source[i]=='\n'||(wb.source[i]=='\r'&&(i+1==wb.length||wb.source[i+1]!='\n')))++current_line;
 unsigned column=0;for(unsigned i=line_start(wb.cursor);i<wb.cursor;++i)column=wb.source[i]=='\t'?(column+4)&~3u:column+1;
 unsigned left=column>=54?column-53:0;
 unsigned top=current_line>=38?current_line-37:0,line=0,x=0,y=18;
 for(unsigned i=0;i<=wb.length&&y<56;++i){unsigned char c=(unsigned char)wb.source[i];if(line>=top){if(i==wb.cursor&&wb.focus==VIOS_WB_EDITOR&&x>=left&&x-left<54){char shown=c>=32&&c<=126?(char)c:' ';vios_text_put(26+x-left,y,&shown,1,0,2);}else if(c>=32&&c<=126&&x>=left&&x-left<54){char shown=(char)c;vios_text_put(26+x-left,y,&shown,1,3,0);}}
  if(c=='\n'||(c=='\r'&&(i+1==wb.length||wb.source[i+1]!='\n'))){++line;if(line>top)++y;x=0;}else if(c=='\r'){}else if(c=='\t')x=(x+4)&~3u;else ++x;
 }
 text(0,56,"F5 Stage/Test  F6 Activate  F7 Save  F8 Undo  F10 Close",79,2);
 text(0,57,wb.dirty?"MODIFIED":"CLEAN",10,wb.dirty?1:3);if(wb.staged&&pending_matches())text(12,57,"STAGED",8,2);if(exact_active())text(22,57,"ACTIVE",8,2);if(wb.saved&&exact_active())text(32,57,"SAVED",8,2);text(44,57,"Bytes:",7,3);number(51,57,wb.length,5);text(58,57,"/4096 Rev:",11,3);number(69,57,(unsigned)wb.revision,10);
 text(0,58,wb.error,79,1);text(0,59,"TAB focus  Left/Right modules/words  Enter edit  Serial CLI available",79,3);
}
